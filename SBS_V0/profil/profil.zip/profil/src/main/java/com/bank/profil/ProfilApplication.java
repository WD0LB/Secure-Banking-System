package com.bank.profil;   

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProfilApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProfilApplication.class, args);
	}

}
